#ifndef _SYS_SEM_H
#define _SYS_SEM_H

#include <linux/sched.h>
#define SEM_TABLE_LEN   20
#define SEM_NAME_LEN    20

typedef struct semaphore{
    char name[SEM_NAME_LEN];
    int value;
    struct task_struct* queue;
}sem_t;

extern sem_t semtable[SEM_TABLE_LEN];

#endif